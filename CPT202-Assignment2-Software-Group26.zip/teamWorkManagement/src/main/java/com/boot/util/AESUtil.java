package com.boot.util;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * 
 * AES Encryption tools
 */
public class AESUtil {

	public static final String charset = "UTF-8";
	public static final String VIPARA = "1369576538321021";

	/**
	 * encrypt password
	 *
	 * @param content
	 * @param password
	 * @return
	 */
	public static String encode(String content, String password) {
		try {
			byte[] encrypt = encode(content.getBytes(charset), password.getBytes(charset));
			return new String(Base64.getEncoder().encode(encrypt), charset);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * decrypt password
	 *
	 * @param content
	 * @param password
	 * @return
	 */
	public static String decode(String content, String password) {
		try {
			byte[] decode = Base64.getDecoder().decode(content.getBytes(charset));
			return new String(decode(decode, password.getBytes(charset)), charset);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * encryption
	 * 
	 * @throws Exception
	 */
	public static byte[] encode(byte[] byteContent, byte[] password) throws Exception {
		return aes(byteContent, password, Cipher.ENCRYPT_MODE);
	}

	/**
	 * decryption
	 * 
	 * @throws Exception
	 */
	public static byte[] decode(byte[] content, byte[] password) throws Exception {
		return aes(content, password, Cipher.DECRYPT_MODE);
	}

	private static byte[] aes(byte[] byteContent, byte[] password, int encryptMode) throws Exception {
		try {
			IvParameterSpec zeroIv = new IvParameterSpec(VIPARA.getBytes());
			SecretKeySpec key = new SecretKeySpec(password, "AES");
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(encryptMode, key, zeroIv);
			return cipher.doFinal(byteContent);
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * Convert binary to hexadecimal
	 * 
	 * @param buf
	 * @return
	 */
	public static String parseByte2HexStr(byte buf[]) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < buf.length; i++) {
			String hex = Integer.toHexString(buf[i] & 0xFF);
			if (hex.length() == 1) {
				hex = '0' + hex;
			}
			sb.append(hex.toUpperCase());
		}
		return sb.toString();
	}

	/**
	 * Convert hexadecimal to binary
	 * 
	 * @param hexStr
	 * @return
	 */
	public static byte[] parseHexStr2Byte(String hexStr) {
		if (hexStr.length() < 1)
			return null;
		byte[] result = new byte[hexStr.length() / 2];
		for (int i = 0; i < hexStr.length() / 2; i++) {
			int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16);
			int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2), 16);
			result[i] = (byte) (high * 16 + low);
		}
		return result;
	}

}
package com.boot.util;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class HttpUtil {
	/*
	 * https request
	 * requestUrl：request address
	 * requestMethod:GET / POST
	 * outputStr:POST request data ,GET push NULL
	 */
   	public static String httpsRequest(String requestUrl, String requestMethod, String outputStr) {
		StringBuffer buffer = new StringBuffer();
		try {

			URL url = new URL(requestUrl);
			HttpsURLConnection httpUrlConn = (HttpsURLConnection) url.openConnection();

			httpUrlConn.setDoOutput(true);
			httpUrlConn.setDoInput(true);
			httpUrlConn.setUseCaches(false);
			// set request mode（GET/POST）
			httpUrlConn.setRequestMethod(requestMethod);

			if ("GET".equalsIgnoreCase(requestMethod))
				httpUrlConn.connect();

			// When there is data to be submitted
			if (null != outputStr) {
				OutputStream outputStream = httpUrlConn.getOutputStream();
				// Pay attention to the coding format to prevent Chinese garbled
				outputStream.write(outputStr.getBytes("UTF-8"));
				outputStream.close();
			}

			// Converts the returned input stream to a string
			InputStream inputStream = httpUrlConn.getInputStream();
			InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "utf-8");
			BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

			String str = null;
			while ((str = bufferedReader.readLine()) != null) {
				buffer.append(str);
			}
			bufferedReader.close();
			inputStreamReader.close();
			// release resource
			inputStream.close();
			inputStream = null;
			httpUrlConn.disconnect();
			return buffer.toString();
		} catch (ConnectException ce) {
			ce.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
   	
	/*
	 * http request
	 * requestUrl：request  address
	 * requestMethod:GET / POST
	 * outputStr:POST request data,GET push NULL
	 */
   	public static String httpRequest(String requestUrl, String requestMethod, String outputStr) {
		StringBuffer buffer = new StringBuffer();
		try {

			URL url = new URL(requestUrl);
			HttpURLConnection httpUrlConn = (HttpURLConnection) url.openConnection();


			httpUrlConn.setDoOutput(true);
			httpUrlConn.setDoInput(true);
			httpUrlConn.setUseCaches(false);
			// set request mode（GET/POST）
			httpUrlConn.setRequestMethod(requestMethod);

			if ("GET".equalsIgnoreCase(requestMethod))
				httpUrlConn.connect();

			// When there is data to be submitted
			if (null != outputStr) {
				OutputStream outputStream = httpUrlConn.getOutputStream();
				// Pay attention to the coding format to prevent Chinese garbled
				outputStream.write(outputStr.getBytes("UTF-8"));
				outputStream.close();
			}

			// Converts the returned input stream to a string
			InputStream inputStream = httpUrlConn.getInputStream();
			InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "utf-8");
			BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

			String str = null;
			while ((str = bufferedReader.readLine()) != null) {
				buffer.append(str);
			}
			bufferedReader.close();
			inputStreamReader.close();
			// release resource
			inputStream.close();
			inputStream = null;
			httpUrlConn.disconnect();
			return buffer.toString();
		} catch (ConnectException ce) {
			ce.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
   	/*
   	 * http request
   	 * requestUrl：request address
   	 */
	public static String httpRequest(String requestUrl) {
		InputStream inputStream = null;
		try {
			URL url = new URL(requestUrl);
			HttpURLConnection httpUrlConn = (HttpURLConnection) url.openConnection();
			httpUrlConn.setDoInput(true);
			httpUrlConn.setRequestMethod("GET");
			httpUrlConn.connect();
			// ge
			inputStream = httpUrlConn.getInputStream();
			InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "utf-8");
			BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

			String str = null;
			StringBuffer buffer = new StringBuffer();
			while ((str = bufferedReader.readLine()) != null) {
				buffer.append(str);
			}
			return buffer.toString();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}
	

	public static String httpParameterFilter(String param){
        String    s    =    "";  
        if    (param.length()    ==    0)    return    "";  
        s    =    param.replaceAll("+",    "%2B");
        s    =    s.replaceAll(" ",        "%20");
        s    =    s.replaceAll("/",        "%2F");  
        s    =    s.replaceAll("?",        "%3F");  
        s    =    s.replaceAll("%'",      "%25");
        s    =    s.replaceAll("#'",      "%23");
        s    =    s.replaceAll("&'",      "%26");
        s    =    s.replaceAll("=",      "%3D");  
        return    s;  
	}
}

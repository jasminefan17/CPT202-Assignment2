package com.boot.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * message class，can reference {@link MessageHandler}
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BaseMessage<T> {
	private boolean success;
	private T data;
	private String message;
	private Integer count,code;

}

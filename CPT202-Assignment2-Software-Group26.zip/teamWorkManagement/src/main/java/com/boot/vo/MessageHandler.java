package com.boot.vo;

/**
 * Generate message
 */
public class MessageHandler {
	/**
	 * Create a message class where the request failed
	 */
	public static BaseMessage<String> createFailedVo(String msg) {
		return new BaseMessage<String>(false, null, msg,null,0);
	}
	/**
	 * Create a message class code that failed the request
	 * @return
	 */
	public static BaseMessage<String> createFailedVo(String msg,Integer code) {
		return new BaseMessage<String>(false, null, msg,null,code);
	}

	/**
	 * Create a successful request message class
	 */
	public static BaseMessage<String> createSuccessVo(String msg) {
		return new BaseMessage<String>(true, null, msg,null,0);
	}

	/**
	 * Create a successful request message class with data
	 */
	public static <T> BaseMessage<T> createSuccessVo(T t, String msg) {
		return new BaseMessage<T>(true, t, msg,null,0);
	}
	public static <T> BaseMessage<T> createSuccessVo(T t, String msg,Integer count) {
		return new BaseMessage<T>(true, t, msg,count,0);
	}
}

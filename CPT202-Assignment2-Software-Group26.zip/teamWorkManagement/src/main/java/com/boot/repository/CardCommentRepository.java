package com.boot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.boot.entity.CardComment;

@Repository
public interface CardCommentRepository extends JpaRepository<CardComment, Integer>,JpaSpecificationExecutor<CardComment> {

}

package com.boot.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.dao.CardCommentDao;
import com.boot.entity.CardComment;
import com.boot.repository.CardCommentRepository;
import com.boot.service.CardCommentService;
import com.boot.vo.TokenHandler;

@Service
public class CardCommentServiceImpl implements CardCommentService{
	@Autowired
	private CardCommentRepository cardCommentRepository;
	@Autowired
	private CardCommentDao cardCommentDao;
	
	@Override
	public void save(CardComment cardComment) {
		if(cardComment!=null&&cardComment.getId()==null) {
			Integer userId = TokenHandler.getBusinessId();
			cardComment.setUserId(userId);
		}
		cardCommentRepository.save(cardComment);
	}

	@Override
	public List<CardComment> getListByCard(Integer cardId) {
		return cardCommentDao.getListByCard(cardId);
	}

	@Override
	public void delete(Integer commentId) {
		cardCommentDao.delete(commentId);
	}

	@Override
	public void cardCommentUpdate(Integer commentId, String comment) {
		cardCommentDao.cardCommentUpdate(commentId,comment);
	}
}

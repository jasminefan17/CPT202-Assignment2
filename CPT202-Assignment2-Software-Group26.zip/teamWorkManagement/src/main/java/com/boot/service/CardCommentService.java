package com.boot.service;

import java.util.List;

import com.boot.entity.CardComment;

public interface CardCommentService {

	void save(CardComment cardComment);

	List<CardComment> getListByCard(Integer cardId);

	void delete(Integer commentId);

	void cardCommentUpdate(Integer commentId, String comment);

}

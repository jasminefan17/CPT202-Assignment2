package com.boot.service;

import java.util.List;

import com.boot.entity.User;

public interface UserService {

	List<User> getList();

}
package com.boot.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.boot.entity.CardComment;

public interface CardCommentDao {

	List<CardComment> getListByCard(@Param("cardId")Integer cardId);

	void delete(@Param("commentId")Integer commentId);

	void cardCommentUpdate(@Param("commentId")Integer commentId,@Param("comment")String comment);

}
